#include <stdio.h>
#include <assert.h>

#define DEVICE(sn) #sn

int main(int argc, char const *argv[])
{
    printf("%s\n", DEVICE(hello));
    printf("%s\n", "DEVICE(hello)");
    assert(2 > 3);
    return 0;
}

#define VERSIONS 2
#if defined x || y || VERSIONS < 3
    int a = 10;
#else
    int a = 8;
#endif
